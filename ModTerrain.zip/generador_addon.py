###############################################################################################
#                                                                                             #
#                         GENERADOR DE TERRENOS MODULARES EN BLENDER                          #
#                                                                                             #
#                                   github.com/CarlaCGDM                                      #
#                                                                                             #
###############################################################################################

###############################################################################################
#                                                                                             #
#                                      INFO DEL ADDON                                         #
#                                                                                             #
###############################################################################################

bl_info = {
    "name": "ModTerrain",
    "author": "SquirrelCarla",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > N",
    "description": "Genera un terreno a partir de un set de módulos especificado.",
    "warning": "",
    "doc_url": "",
    "category": "",
}

###############################################################################################
#                                                                                             #
#                               GENERANDO INDICE DE REFERENCIA                                #
#                                                                                             #
###############################################################################################

import bpy
import math

tileset_completo = []
indice = []
    
def comprobar_borde(modulo1,modulo2,direccion:tuple):
    
    #direcciones posibles: (0,1),(0,-1),(-1,0),(1,0)
    
    vertices_modulo1 = set()
    vertices_modulo2 = set()
    
    X,Y = direccion
    
    #izquierda y derecha
    if X == 0:
    
        for v in modulo1.data.vertices:
            y = round(v.co.y,1)
            if y == 0.5*Y:
                x = round(v.co.x,2)
                z = round(v.co.z,2)
                vertices_modulo1.add((x,z))
                
        for v in modulo2.data.vertices:
            y = round(v.co.y,1)
            if y == -0.5*Y:
                x = round(v.co.x,2)
                z = round(v.co.z,2)
                vertices_modulo2.add((x,z))
    
    #arriba y abajo      
    else:
        
        for v in modulo1.data.vertices:
            x = round(v.co.x,1)
            if x == 0.5*X:
                y = round(v.co.y,2)
                z = round(v.co.z,2)
                vertices_modulo1.add((y,z))
                
        for v in modulo2.data.vertices:
            x = round(v.co.x,1)
            if x == -0.5*X:
                y = round(v.co.y,2)
                z = round(v.co.z,2)
                vertices_modulo2.add((y,z))
            
    if vertices_modulo1 == vertices_modulo2:
        return True
    else:
        return False
    
def indice_conexiones(tileset:list):
    
    direcciones = [ (0,1), (0,-1), (1,0), (-1,0) ]
    indice = {}
    
    #rellenamos el indice
    for t in tileset:
        indice[t.name] = {}
        for dir in direcciones:
            indice[t.name][dir] = []
            for t2 in tileset:
                if comprobar_borde(t,t2,dir) == True:
                    indice[t.name][dir].append(t2.name)
        
    return indice


def rotaciones(tileset:list):
    
    #si ya existe la coleccion, borrarla:
    coll = bpy.data.collections.get("TilesetCompleto")
    if coll != None:
        for obj in coll.objects:
            m = obj.data
            bpy.data.objects.remove(obj)
            bpy.data.meshes.remove(m)
        bpy.data.collections.remove(coll)
    
    #colección para las rotaciones:
    coll = bpy.data.collections.new("TilesetCompleto")
    bpy.context.scene.collection.children.link(coll)

    
    #añadimos los objetos
    for t in tileset:
        
        t1 = bpy.data.objects.new(t.name + '_0', t.data.copy())
        coll.objects.link(t1)
        
        t2 = bpy.data.objects.new(t.name + '_90', t.data.copy())
        t2.rotation_euler[2] = math.radians(90)
        coll.objects.link(t2)
        
        t3 = bpy.data.objects.new(t.name + '_180', t.data.copy())
        t3.rotation_euler[2] = math.radians(180)
        coll.objects.link(t3)
        
        t4 = bpy.data.objects.new(t.name + '_270', t.data.copy())
        t4.rotation_euler[2] = math.radians(270)
        coll.objects.link(t4)
        
    #aplicamos la rotacion y los nombres de las mallas
    for obj in coll.objects:
        obj.data.name = obj.name
        obj.select_set(True)
        bpy.ops.object.transform_apply(rotation=True)

###############################################################################################
#                                                                                             #
#                                GENERACIÓN DE CUADRÍCULA                                     #
#                                                                                             #
###############################################################################################

import random

def grid_vacio(alto,ancho):
    
    #creamos la cuadrícula rellena de datos vacíos
    grid = []
    for i in range(alto):
        fila = []
        for j in range(ancho):
            fila.append("##No_Data##")
        grid.append(fila)
            
    return grid

def adyacentes_vacios(grid:list,celda:tuple):
    
    direcciones = [ (0,1), (0,-1), (1,0), (-1,0) ]
    vacios = []
    y,x = celda
    
    #por cada dirección, si la siguiente celda está vacía la guardamos
    for dir in direcciones:
        dy,dx = dir
        siguiente = (y+dy,x+dx)
        if siguiente[0] in range(len(grid)) and siguiente[1] in range(len(grid[0])):
            valor = grid[siguiente[0]][siguiente[1]]
            if valor == "##No_Data##":
                vacios.append(siguiente)
                
    return vacios

def adyacentes_ocupados(grid:list,celda:tuple):
    
    direcciones = [ (0,1), (0,-1), (1,0), (-1,0) ]
    ocupados = []
    
    #por cada dirección, si la siguiente celda está ocupada la guardamos junto con la dirección
    y,x = celda
    for dir in direcciones:
        dy,dx = dir
        siguiente = (y+dy,x+dx)
        if siguiente[0] in range(len(grid)) and siguiente[1] in range(len(grid[0])):
            valor = grid[siguiente[0]][siguiente[1]]
            if valor != "##No_Data##":
                ocupados.append(((-dy,-dx),valor)) 
                
    return ocupados

def crear_o_reemplazar_coleccion(nombre_coleccion:str):
    
    coll = bpy.data.collections.get(nombre_coleccion)
    if coll != None:
        for obj in coll.objects:
            bpy.data.objects.remove(obj)
        bpy.data.collections.remove(coll)
          
    coleccion = bpy.data.collections.new(nombre_coleccion)
    bpy.context.scene.collection.children.link(coleccion)

###############################################################################################
#                                                                                             #
#                                            BOTONES                                          #
#                                                                                             #
###############################################################################################

class BotonCargarModulos(bpy.types.Operator):
    """Prepara un set modular para poder generar terrenos con él."""
    bl_idname = "modterrain.cargar"
    bl_label = "Cargar Módulos"

    def execute(self, context):
        
        #limpiar el terreno
        crear_o_reemplazar_coleccion("Detalles")
        
        #sets modulares
        global tileset_completo
        global indice
        
        tileset_completo = []
        tileset_inicial = []
        
        #rellenamos el primer set
        for obj in bpy.data.collections[context.scene.modulos].objects:
            for i in range(obj.frecuencia):
                tileset_inicial.append(obj)
        
        #generamos las rotaciones y rellenamos el segundo set
        rotaciones(tileset_inicial)
        
        for obj in bpy.data.collections["TilesetCompleto"].objects:
            tileset_completo.append(obj)

        #generamos el indice con la informacion de adyacencia
        
        indice = indice_conexiones(tileset_completo)
        
        return {'FINISHED'}

class BotonGenerarTerreno(bpy.types.Operator):
    """Genera un terreno de 10x10."""
    bl_idname = "modterrain.generar"
    bl_label = "Generar Terreno"

    def execute(self, context):
        
        #ocultar modulos
        bpy.data.collections['TilesetCompleto'].hide_viewport = True
        
        #limpiar detalles
        crear_o_reemplazar_coleccion("Detalles")
        
        global tileset_completo
        global indice
        
        #grid vacío
        alto,ancho = (context.scene.alto,context.scene.ancho)
        grid = grid_vacio(alto,ancho)
        
        #colección para el terreno
        coll = bpy.data.collections.get("Terreno")
        if coll != None:
            for obj in coll.objects:
                bpy.data.objects.remove(obj)
            bpy.data.collections.remove(coll)
        
        terreno = bpy.data.collections.new('Terreno')
        bpy.context.scene.collection.children.link(terreno)
        
        #primera casilla
        inicio = (0,0)
        y,x = inicio
        
        modulo = random.choice(tileset_completo).data
        grid[y][x] = modulo.name
        obj = bpy.data.objects.new(modulo.name + '_Linked', modulo)
        terreno.objects.link(obj)
        obj.location = (x,y,0)
        
        #bucle de generación
        cola = []
        
        celdas_vecinas = adyacentes_vacios(grid,inicio)
        cola.extend(celdas_vecinas)
        
        while len(cola) > 0:
            
            siguiente = cola.pop()
            y,x = siguiente
            
            celdas_vecinas = adyacentes_ocupados(grid,siguiente)
            
            posibles = []
            
            for cel in celdas_vecinas:
                dir,nombre = cel 
                posibles.append(indice[nombre][dir])
                
            modulos_en_todos = list(set.intersection(*map(set, posibles)))
            
            #elegir el siguiente módulo al azar
            if len(modulos_en_todos) > 0:
                modulo = random.choice(modulos_en_todos)
                grid[y][x] = modulo
            
                #colocar una copia del modulo en el terreno
                modulo_m = bpy.data.objects[modulo].data
                obj = bpy.data.objects.new(modulo + '_Linked', modulo_m)
            
                terreno.objects.link(obj)
                obj.location = (y,x,0)
            
                #añadir sus adyacentes a la cola
                celdas_vecinas = adyacentes_vacios(grid,siguiente)
                for cel in celdas_vecinas:
                    if cel not in cola:
                        cola.append(cel)
        return {'FINISHED'}
    
class BotonGenerarDetalles(bpy.types.Operator):
    """Añade detalles al terreno."""
    bl_idname = "modterrain.detalles"
    bl_label = "Generar Detalles"

    def execute(self, context):
        
        #detalles sobre el terreno
        crear_o_reemplazar_coleccion("Detalles")
        detalles = bpy.data.collections.get("Detalles")
        assets = []
        
        #rellenamos la lista de opciones
        for obj in bpy.data.collections["Assets"].objects:
            for i in range(obj.frecuencia):
                assets.append(obj)
        
        
        for obj in bpy.data.collections.get('Terreno').objects:
            obj_loc = obj.location
            for face in obj.data.polygons:
                loc = obj_loc + face.center
                #si el material de la cara es el material hierba
                if face.material_index == 0:
                    if random.randint(1,20) == 1:
                        #añadimos un asset al azar
                        asset = random.choice(assets).data
                        obj = bpy.data.objects.new(asset.name + "_Linked", asset)
                        detalles.objects.link(obj)
                        obj.location = loc
                        obj.rotation_euler[2] = math.radians(random.choice([0,90,180,270]))
            
        return {'FINISHED'}
    
###############################################################################################
#                                                                                             #
#                                       MENU PRINCIPAL                                        #
#                                                                                             #
###############################################################################################
    
#Creamos la clase menú:        
class CustomPanel(bpy.types.Panel):
    bl_label = "ModTerrain"
    bl_idname = "OBJECT_PT_hello"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "ModTerrain"

    def draw(self, context):
        layout = self.layout

        column = layout.column()
        
        column.prop(context.object, "frecuencia")
        
        row = column.row()
        row.prop(context.scene,"modulos")
        row.operator(BotonCargarModulos.bl_idname, text="", icon='CHECKMARK')
        
        row1 = column.row()
        row1.prop(context.scene,"alto")
        row1.prop(context.scene,"ancho")   
        
        column.operator(BotonGenerarTerreno.bl_idname, text="Generar Terreno", icon='VIEW_PERSPECTIVE')
        column.operator(BotonGenerarDetalles.bl_idname, text="Generar Detalles", icon='AUTO')
        
###############################################################################################
#                                                                                             #
#                                      REGISTRAR ADDON                                        #
#                                                                                             #
###############################################################################################

from bpy.utils import register_class, unregister_class

_classes = [
    BotonCargarModulos,
    BotonGenerarTerreno,
    BotonGenerarDetalles,
    CustomPanel
]

def register():
    for cls in _classes:
        register_class(cls)
    bpy.types.Scene.ancho = bpy.props.IntProperty(name="Ancho",
                                                            description="Tamaño en el eje Y del terreno generado.",     
                                                            min=0, 
                                                            max=100, 
                                                            default=5)
    bpy.types.Scene.alto = bpy.props.IntProperty(name="Alto",
                                                            description="Tamaño en el eje X del terreno generado.",     
                                                            min=0, 
                                                            max=100, 
                                                            default=5)
    bpy.types.Object.frecuencia = bpy.props.IntProperty(name="Frecuencia del Objeto Seleccionado",
                                                            description="Proporción en la cual se colocará el objeto seleccionado en la escena.",     
                                                            min=0, 
                                                            max=250, 
                                                            default=1)
    bpy.types.Scene.modulos = bpy.props.StringProperty(name="Módulos",
                                                            description="Nombre de la colección donde se encuentran los módulos.",
                                                            default="TilesetInicial")

def unregister():
    for cls in _classes:
        unregister_class(cls)
        bpy.types.Scene.ancho
        bpy.types.Scene.alto
        bpy.types.Object.frecuencia
        bpy.types.Scene.modulos


if __name__ == "__main__":
    register()